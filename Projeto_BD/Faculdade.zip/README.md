# Esse e um projeto com o intuido de criar um crud, utilizando linguagem de programação, html e css, banco de dados, api, e ser hospedado numa plataforma cloud
